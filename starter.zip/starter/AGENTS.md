# Repository Guidelines

## Project Structure & Module Organization
- Root app: `app.py` (Streamlit entry). Shared state: `state_manager.py`.
- Services: `services/` (Kafka admin, DuckDB, app-state helpers).
- Kafka clients: `kafka/` (`producer.py`, `consumer.py`).
- UI bootstrap: `ui/bootstrap.py` (session init, sidebar status).
- Schemas: `schemas/schemas.py` (+ `SchemaValidator`).
- Pages: `pages/` with ordered filenames like `01_*.py`.
- Local data: `starter_state/` (JSON files created at runtime).

## Build, Test, and Development Commands
- Create/activate env (Conda):
  - `conda env update -f environment.yml`
  - `conda activate k2`
- Run app (from repo root):
  - `streamlit run starter/app.py`
- Run app (from this folder):
  - `cd starter && streamlit run app.py`
- Environment variables: define `.env` with `BOOTSTRAP_SERVERS`, `API_KEY`, `API_SECRET`.

## Coding Style & Naming Conventions
- Python 3, PEP 8, 4-space indentation. Favor type hints and docstrings (see services and schemas).
- Files/modules: `snake_case.py`; classes: `CamelCase`; constants: `UPPER_SNAKE`.
- Pages: prefix with two-digit order, e.g., `pages/01_Create_Messages.py` to control sidebar order.
- Keep Streamlit pages thin; put Kafka/IO logic in `services/` or `kafka/`.

## Testing Guidelines
- No test runner is bundled; validate changes by running the app and using Pages:
  - Produce sample events on “Create Messages”, then consume on “Consumer Topic Management”.
  - Use “System Settings” to create/flush topics and clear local state.
- Schema checks: use `SchemaValidator` in `schemas/schemas.py` before producing.
- If adding unit tests, prefer `pytest` and isolate Kafka by mocking producers/consumers.

## Commit & Pull Request Guidelines
- Commits: use clear, scoped messages. Recommended format (Conventional Commits):
  - `feat: add Topics Overview table`
  - `fix: handle missing .env gracefully`
- Pull requests should include:
  - Summary of changes and rationale; reference issue IDs.
  - Screenshots/GIFs of updated Streamlit views when UI changes.
  - Run instructions, notable config (topics, env vars), and any migration steps.

## Security & Configuration Tips
- Do not commit secrets. `.env` is git-ignored; verify Kafka connectivity there.
- Demo-friendly defaults use 1 partition; adjust in “System Settings”.
- Local JSON in `starter_state/` is for demos; consider a DB for production.
