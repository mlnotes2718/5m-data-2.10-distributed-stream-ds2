# Kafka App Starter Kit (Conda)

This starter provides a skeletal Streamlit + Kafka app for departments to build their own dashboards in the pizza fulfillment process. It is generic by design so teams can adapt topics, schemas, and pages.

Includes
- Kafka admin helpers (create/delete/flush topics)
- General state management (JSON files) and optional DuckDB analytics
- Streamlit scaffolding (Welcome + generic producer/consumer/publisher pages)


## Conda Environment Setup (based on environment.yml and lock file)

The repo ships with `starter/environment.yml` for this starter and a root `conda-lock.yml`.

Option A — Use the starter environment.yml (recommended)
- Create/update env and activate:
  - `conda env update -f starter/environment.yml`
  - `conda activate k2`

Option B — Use the lock file (pin exact versions)
- Install conda-lock if needed: `pip install conda-lock`
- Create env from lock: `conda-lock install -n k2 conda-lock.yml`
- Activate: `conda activate k2`

Environment variables
- Create a `.env` at the repository root (not committed):
  - `BOOTSTRAP_SERVERS=...`
  - `API_KEY=...`
  - `API_SECRET=...`

Run the starter
- From repo root: `streamlit run starter/app.py`
- Or from the starter folder: `cd starter && streamlit run app.py`
  - All paths and imports are designed to work in both cases.

## Structure (relative paths)

```
./
  app.py                      # Welcome dashboard with Kafka/Topics/Orders metrics
  state_manager.py            # JSON-backed persistence for small apps
  ui/
    bootstrap.py              # Session init, sidebar status, periodic save
  services/
    kafka_admin.py            # List/create/delete/flush topics (AdminClient)
    app_state.py              # Save/clear state helpers
    duckdb_engine.py          # Query JSON state using DuckDB (optional)
  kafka/
    producer.py               # DepartmentProducer (publish JSON)
    consumer.py               # DepartmentConsumer (background consume)
  schemas/
    schemas.py                # JSONSchema template + validator
  pages/
    01_Create_Messages.py              # Producer-side: publish messages
    02_Consumer_Topic_Management.py    # Consumer-side: view/manage consumed data
    03_Publisher_Topic_Management.py   # Publisher-side: send updates/commands
    04_System_Settings.py              # Admin: topics + state reset
```

## How to Customize (relative paths)

- Topics: edit `DEFAULT_TOPICS` in `kafka/{producer,consumer}.py`. Use System Settings to create/flush topics (default 1 partition for demos).
- Schemas: define JSON schemas in `schemas/schemas.py` and validate before producing/after consuming.
- Pages: rename files/titles and adapt content. Each page is commented to guide beginners.
- State & joins: use `starter_state/` JSON files with DuckDB enabled by default to run SQL “in place” over JSON (no external DB required). You can later swap to a database if needed.
  - Referential joins: use `DuckDBEngine.join_state_by_key(key_field='id')` to join arrays of records with a status map using a selectable key.

## Notes

- Uses plain JSON over Kafka (no Schema Registry) for simplicity.
- JSON files are fine for teaching; move to a DB for production.
- Never commit secrets — `.env` is ignored by git.

## Troubleshooting

- Kafka not connected: validate `.env` values and cluster access.
- Offsets look stale: use System Settings → Flush Topics (set partitions) and tick “Also clear app state”.
- DuckDB missing: `pip install duckdb` in the `k2` env.

## Starter Prompt: Build a Welcome Dashboard

Use this prompt to upgrade the starter’s Welcome page to a fully featured Topics Overview dashboard:

"""
Refactor starter/app.py to implement a Topics Overview dashboard:

1) Topics Overview table
   - Columns: Topic, Messages, Kafka Offsets, App Offsets, Consumer Lag
   - Messages: sum high−low per partition via `consumer.get_watermark_offsets(TopicPartition(topic, p))`
   - Kafka Offsets: `consumer.committed([...TopicPartition...])` for actual partitions only
   - App Offsets: read from `starter_state/consumer_offsets.json` and display only current partitions
   - Consumer Lag: sum over partitions (high − committed)
   - Wrap Kafka queries in `st.spinner("Loading Kafka topic data…")`
   - Add a checkbox to show per-partition debug (Low, High, Committed, Lag)

2) Consumers and admin
   - Reuse `starter.kafka.consumer.get_department_consumer()` to access the underlying `consumer` for watermark/committed calls
   - Use `starter.services.kafka_admin.list_topics(admin_client)` to enumerate topics and partitions

3) Keep starter constraints
   - Do not remove existing starter code or pages
   - Keep JSON state folder as `starter_state/`
   - Ensure all code paths handle missing Kafka gracefully (show “-” and avoid exceptions)

4) Optional: JSON joins in pages
   - Add a selectbox to choose `key_field` and display `DuckDBEngine.join_state_by_key(key_field)` on 02_Consumer_Topic_Management

Be explicit and comment each major helper and block so beginners understand what’s happening and where to customize topics, schemas, and UI.
"""

## Starter Prompt: Build the Full Department App

Use this prompt to implement a complete departmental dashboard with the provided scaffolding (no external references assumed):

"""
Implement a full-featured app with these pages and behaviors:

Welcome (root app)
- Show metrics: Kafka connectivity, topics count, records/delivered counts from local state.
- Add a Topics Overview table with: Topic, Messages (sum high−low), Kafka Offsets (committed per partition), App Offsets (from local JSON, filtered to current partitions), Consumer Lag.
- Include a loading spinner around Kafka calls and a per-partition debug toggle (Low/High/Committed/Lag).

01_Create_Messages
- Provide a form to publish JSON to a configured topic using the producer helper.
- Validate against schemas/schemas.py and show validation errors before publishing.
- On success, display the payload, update in-memory state for responsiveness, and persist via StateManager.

02_Consumer_Topic_Management
- Controls to start/stop the background consumer and show consumer info (running state, stored messages).
- Display recent messages and update a local status map keyed by a chosen id field.
- Persist app offsets to JSON only when non-empty; show a summary of saved offsets.

03_Publisher_Topic_Management
- Controls for publishing updates/commands (e.g., status changes) to a configured topic via the producer helper.
- When a delivered-like event is produced/consumed, capture its timestamp from the message the first time it’s seen and reuse it for stable display.
- Rebuild in-progress/processed lists from the current records + status map every render; remove stale entries and deduplicate by id.

04_System_Settings
- List topics; create/delete topics.
- Add a Flush Topics section with a partitions selector (default 1) and a checkbox to clear app state (delete local JSON and reset consumers so new groups have no prior commits).
- Optionally add a “Clear App Offsets Now” button to delete only the offsets file.

Schemas Page (optional)
- Render JSON schemas and a simple validation harness with a text area and a validate button. Include examples and display errors to guide beginners.

Shared behaviors
- Periodically save session state to JSON and handle shutdown gracefully.
- Handle missing Kafka by rendering “-” values without exceptions.
- Centralize topics, groups, and key field configuration via constants.
"""

## Starter Prompt: Create a Pizza Fulfillment App (from this starter)

This prompt directs an LLM (or developer) to build a pizza-ordering fulfillment dashboard using this starter as a base. It must create new pages (do not modify the existing starter pages). Use the starter pages as templates:
- Use `pages/01_Create_Messages.py` as the template for the Pizza Orders page.
- Use `pages/02_Consumer_Topic_Management.py` as the template for the Order Tracking page.
- Use `pages/03_Publisher_Topic_Management.py` as the template for the Delivery Manager page.
- Use `pages/04_System_Settings.py` as the template for the System Settings page.

"""
Goal
- Create a pizza fulfillment dashboard with four brand-new pages (new filenames) and the following schemas and topics.

Schemas (JSON)
- Pizza Order (topic: `pizza-orders`)
  - Fields: `order_id` (string, required), `customer_name` (string, required), `pizza_size` (enum: Small/Medium/Large, required), `toppings` (array[string], minItems 1, required), `status` (enum: ordered/preparing/ready/delivered, default ordered)
- Delivery Status (topic: `pizza-delivery-status`)
  - Fields: `order_id` (string, required), `status` (enum: ordered/preparing/ready/delivered, required), `timestamp` (string, ISO8601, required)
- Provide a `SchemaValidator` with `validate_order()` and `validate_status()`; fail early on invalid inputs.

Kafka setup
- Producer config uses BOOTSTRAP_SERVERS/API_KEY/API_SECRET from `.env`.
- Consumer config: group ids `pizza-order-consumer` and `pizza-status-consumer`, `auto.offset.reset=earliest`, manual commit.
- Topics: initialize via a new System Settings page to create/flush `pizza-orders` and `pizza-delivery-status` (default 1 partition).

New pages (create these as brand-new files; do not edit existing starter pages)
- `pages/01_Pizza_Orders.py` (start from `pages/01_Create_Messages.py`)
  - A form to create orders conforming to the Pizza Order schema; validate, produce to `pizza-orders` with key=`order_id`.
  - On success, append to in-memory `orders` list and persist via StateManager.
  - Show an “Order Summary” of the submitted payload.

- `pages/02_Order_Tracking.py` (start from `pages/02_Consumer_Topic_Management.py`)
  - Start an order consumer for `pizza-orders` and a status consumer for `pizza-delivery-status` (background threads).
  - Build a consolidated view of all known orders from: (a) persisted orders; (b) in-memory `orders`; (c) recent Kafka messages.
  - Maintain `order_statuses` map keyed by `order_id`. Apply status updates from Kafka. Partition orders into “In Progress” (status != delivered) and “Processed” (status == delivered).
  - Render a visual status timeline using the four statuses; current and future steps should render as completed/pending respectively.
  - Include a reload button that forces a reload from persisted StateManager files and re-runs the page.

- `pages/03_Delivery_Manager.py` (start from `pages/03_Publisher_Topic_Management.py`)
  - Provide controls to publish Delivery Status updates to `pizza-delivery-status` using the producer helper and the schema validator.
  - When a delivered message is seen for an `order_id`, capture its `timestamp` from Kafka the first time and reuse it on future renders (stable “Completed” time).
  - Rebuild `in_progress_orders` and `processed_orders` from the unified order set + `order_statuses` each render; deduplicate by `order_id`; prune stale entries.
  - Offer a button to clear processed orders from local state (but note that if an order’s status remains delivered, it will reappear on rebuild).

- `pages/04_System_Settings.py` (start from `pages/04_System_Settings.py`)
  - Show existing topics, controls to create/delete topics, and a “Flush Topics” section (delete + recreate) with a partitions selector (default 1).
  - Include a checkbox to also clear local app state (delete JSON files) and reset consumers (e.g., by bumping any suffix mechanism so new groups start clean).
  - Optionally add a “Clear App Offsets Now” button to delete only `starter_state/consumer_offsets.json`.

Welcome (app.py)
- Provide top-level metrics: Kafka connectivity, topics count, orders total and delivered from persisted state.
- Add a Topics Overview table for `pizza-orders` and `pizza-delivery-status`:
  - Messages: sum of (high − low) via `consumer.get_watermark_offsets(TopicPartition(topic, p))` across real partitions.
  - Kafka Offsets: committed offsets from `consumer.committed([...TopicPartition...])` for actual partitions only.
  - App Offsets: read from local JSON (`starter_state/consumer_offsets.json`), filtered to only current partitions.
  - Consumer Lag: sum over partitions (high − committed).
  - Wrap Kafka inspection in `st.spinner("Loading Kafka topic data…")` and add a per-partition debug toggle (Low/High/Committed/Lag).

State & joins
- Persist `orders`, `order_statuses`, `in_progress_orders`, `processed_orders` using StateManager under `starter_state/`.
- Use DuckDBEngine to implement a generic join utility to join records with a status map using a selected key (e.g., `order_id`), and (optionally) surface this in tracking for analytics.

Quality bar
- Add docstrings/comments on each major function and block explaining the logic and how to customize.
- Handle missing Kafka by rendering “-” values and avoiding exceptions.
- Keep offsets persistence idempotent; don’t recreate files when empty.
"""
