"""Template Kafka JSON consumer for department apps.

Two patterns:
1) Call `start_consuming([topic])` to run a background thread and call `get_recent_messages()` from your page.
2) Use `consume_once()` pattern (not shown) for on-demand pulls.
"""

import json
import os
import threading
import time
from typing import Any, Dict, List, Optional

from confluent_kafka import Consumer, KafkaException, TopicPartition


DEFAULT_TOPICS = {
    "orders": "pizza-orders",
    "status": "pizza-delivery-status",
}


class DepartmentConsumer:
    """Thin JSON consumer wrapper with a background thread.

    Pattern:
    - call start_consuming([topic]) to begin polling in a thread
    - use get_recent_messages() in your Streamlit page to display data
    - call stop_consuming() on exit or via a button
    """
    def __init__(self, group_id: str = "dept-consumer"):
        self.group_id = group_id
        self.consumer = Consumer(
            {
                "bootstrap.servers": os.getenv("BOOTSTRAP_SERVERS", ""),
                "sasl.mechanisms": "PLAIN",
                "security.protocol": "SASL_SSL",
                "sasl.username": os.getenv("API_KEY", ""),
                "sasl.password": os.getenv("API_SECRET", ""),
                "group.id": self.group_id,
                "auto.offset.reset": "earliest",
                "enable.auto.commit": False,
                "client.id": f"starter-{self.group_id}",
                "broker.address.family": "v4",
            }
        )
        self.messages: List[Dict[str, Any]] = []
        self.running = False
        self.thread: Optional[threading.Thread] = None

    def start_consuming(self, topics: List[str]) -> None:
        """Subscribe to topics and start the background polling loop."""
        if self.running:
            return
        self.consumer.subscribe(topics)
        self.running = True
        self.thread = threading.Thread(target=self._loop, daemon=True)
        self.thread.start()

    def stop_consuming(self) -> None:
        """Signal the background loop to stop and close the consumer."""
        self.running = False
        if self.thread:
            self.thread.join(timeout=3)
        try:
            self.consumer.close()
        except Exception:
            pass

    def _loop(self):
        """Background polling loop. Converts JSON bytes into dicts.

        For each message:
        - parse JSON
        - attach Kafka metadata under `_kafka`
        - append to in-memory buffer
        - commit synchronously (demo-friendly)
        """
        while self.running:
            try:
                msg = self.consumer.poll(1.0)
                if msg is None:
                    continue
                if msg.error():
                    print(f"Consumer error: {msg.error()}")
                    continue
                payload = json.loads(msg.value().decode("utf-8"))
                payload["_kafka"] = {
                    "topic": msg.topic(),
                    "partition": msg.partition(),
                    "offset": msg.offset(),
                }
                self.messages.append(payload)
                self.messages = self.messages[-1000:]
                try:
                    self.consumer.commit(message=msg, asynchronous=False)
                except KafkaException as e:
                    print(f"Commit failed: {e}")
            except Exception as e:
                if (not self.running) or ("Consumer closed" in str(e)):
                    break
                time.sleep(0.5)

    def get_recent_messages(self, limit: int = 50) -> List[Dict[str, Any]]:
        """Return the newest N messages the consumer has stored locally."""
        return self.messages[-limit:]


_instance: Optional[DepartmentConsumer] = None


def get_department_consumer(group_id: str = "dept-consumer") -> DepartmentConsumer:
    global _instance
    if _instance is None:
        _instance = DepartmentConsumer(group_id)
    return _instance
