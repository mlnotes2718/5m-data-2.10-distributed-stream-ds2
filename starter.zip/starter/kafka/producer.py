"""Template Kafka JSON producer for department apps.

Usage:
    from starter.kafka.producer import get_department_producer
    p = get_department_producer()
    ok, msg = p.produce_json({"event": "example", "id": "123"}, topic="dept-events")
"""

import json
import os
from typing import Dict, Any, Tuple, Optional
from confluent_kafka import Producer


DEFAULT_TOPICS = {
    "orders": "pizza-orders",                  # change to your department topic(s)
    "status": "pizza-delivery-status",
}


class DepartmentProducer:
    """Thin JSON producer wrapper for department apps.

    Why use a wrapper:
    - Centralizes Kafka config (SASL, client.id) and retries/flush.
    - Keeps Streamlit pages clean and focused on UI.
    """
    def __init__(self):
        self.producer = Producer(
            {
                "bootstrap.servers": os.getenv("BOOTSTRAP_SERVERS", ""),
                "sasl.mechanisms": "PLAIN",
                "security.protocol": "SASL_SSL",
                "sasl.username": os.getenv("API_KEY", ""),
                "sasl.password": os.getenv("API_SECRET", ""),
                "client.id": "dept-producer",
                "broker.address.family": "v4",
            }
        )

    def _delivery(self, err, msg):
        """Delivery callback to log success/failure per message."""
        if err:
            print(f"Delivery failed: {err}")
        else:
            print(f"Delivered to {msg.topic()}[{msg.partition()}] @ {msg.offset()}")

    def produce_json(self, payload: Dict[str, Any], topic: str, key: Optional[str] = None) -> Tuple[bool, str]:
        """Serialize to JSON and send to Kafka.

        Returns (ok, message). Flushes with a short timeout to keep UI responsive.
        """
        try:
            self.producer.produce(topic=topic, key=key, value=json.dumps(payload), callback=self._delivery)
            self.producer.flush(5)
            return True, "sent"
        except Exception as e:
            return False, str(e)


_instance: Optional[DepartmentProducer] = None


def get_department_producer() -> DepartmentProducer:
    global _instance
    if _instance is None:
        _instance = DepartmentProducer()
    return _instance
