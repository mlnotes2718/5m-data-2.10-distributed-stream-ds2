"""Starter Welcome Page

This is the entry point for departmental apps. It demonstrates how to:
- initialize shared services (state, Kafka admin, DuckDB)
- show a few high-level metrics
- guide users to Pages in the sidebar
"""

import streamlit as st

# Support running from repo root or from within this folder
try:
    from starter.ui.bootstrap import initialize, sidebar_status
    from starter.services.kafka_admin import list_topics
except Exception:
    from ui.bootstrap import initialize, sidebar_status
    from services.kafka_admin import list_topics


st.set_page_config(page_title="Welcome", page_icon="🍕", layout="wide", initial_sidebar_state="expanded")

st.sidebar.title("Department Starter App")
initialize()

st.title("Welcome — Department Starter Dashboard")
st.caption("Use this as a base. Customize topics, messages, and pages for your team.")

col1, col2, col3, col4 = st.columns([1, 1, 1, 2])
admin_client = st.session_state.get("admin_client")  # may be None if .env missing

with col1:
    st.metric("Kafka", "Connected" if admin_client else "Disconnected")

topics_count = 0  # default if broker not reachable
if admin_client:
    try:
        topics = list_topics(admin_client)
        topics_count = len(topics)
    except Exception:
        pass
with col2:
    st.metric("Topics", topics_count)

orders, statuses = st.session_state.state_manager.load_order_states()
with col3:
    st.metric("Orders", len(orders))
with col4:
    processed = sum(1 for s in statuses.values() if s == "delivered")
    st.metric("Delivered", processed)

st.markdown("---")
st.subheader("Pages")
st.write("- Orders Dashboard\n- Tracking Dashboard\n- Operations Manager\n- System Settings")

sidebar_status()
