import json
import os
from datetime import datetime
from typing import Dict, Any, Tuple, List


class StateManager:
    """
    Minimal JSON-backed persistence for starter apps.

    Why this exists:
    - Gives beginners a concrete place to "save and load" app data without setting up a database.
    - Makes it easy to reason about state across Streamlit reruns (files are the source of truth).

    What it stores (by default under `starter_state/`):
    - order_states.json: an array of records ("orders" or generic "messages") and a status map keyed by id
    - delivery_states.json: two convenience buckets (in_progress_orders, processed_orders)
    - consumer_offsets.json: optional map for persisting consumer offsets (useful for demos)

    Swap this out for a real DB when needed; keep the method signatures to minimize refactors.
    """

    def __init__(self, state_dir: str = "starter_state"):
        self.state_dir = state_dir
        os.makedirs(self.state_dir, exist_ok=True)

    def _path(self, name: str) -> str:
        return os.path.join(self.state_dir, name)

    # Orders + statuses ------------------------------------------------------
    def save_order_states(self, orders: List[Dict[str, Any]], order_statuses: Dict[str, str]) -> None:
        """Persist the current list of records and their statuses.

        Parameters
        - orders: a list of dicts (your domain records)
        - order_statuses: mapping of record id -> status string
        """
        data = {"orders": orders, "order_statuses": order_statuses, "last_updated": self._now()}
        with open(self._path("order_states.json"), "w") as f:
            json.dump(data, f, indent=2)

    def load_order_states(self) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
        """Load list of records and status map from disk.

        Returns
        - (orders, statuses): orders is a list[dict], statuses is dict[id -> status]
        """
        try:
            with open(self._path("order_states.json"), "r") as f:
                data = json.load(f)
            return data.get("orders", []), data.get("order_statuses", {})
        except Exception:
            return [], {}

    # Delivery buckets -------------------------------------------------------
    def save_delivery_states(self, in_progress: List[Dict[str, Any]], processed: List[Dict[str, Any]]) -> None:
        """Persist convenience buckets for UI lists.

        These are derived views and optional; keep or remove per department needs.
        """
        data = {"in_progress_orders": in_progress, "processed_orders": processed, "last_updated": self._now()}
        with open(self._path("delivery_states.json"), "w") as f:
            json.dump(data, f, indent=2)

    def load_delivery_states(self) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """Load convenience buckets for UI lists.

        Returns
        - (in_progress, processed)
        """
        try:
            with open(self._path("delivery_states.json"), "r") as f:
                data = json.load(f)
            return data.get("in_progress_orders", []), data.get("processed_orders", [])
        except Exception:
            return [], []

    # Consumer offsets (optional) --------------------------------------------
    def save_consumer_offsets(self, consumer_offsets: Dict[str, Any]) -> None:
        """Persist consumer offsets (optional for demos).

        Structure is up to you; a common shape is:
          { "group-id": { "topic-name": { partition: offset, ... } } }
        """
        data = {"consumer_offsets": consumer_offsets, "last_updated": self._now()}
        with open(self._path("consumer_offsets.json"), "w") as f:
            json.dump(data, f, indent=2)

    def load_consumer_offsets(self) -> Dict[str, Any]:
        """Load persisted consumer offsets mapping or return an empty dict."""
        try:
            with open(self._path("consumer_offsets.json"), "r") as f:
                data = json.load(f)
            return data.get("consumer_offsets", {})
        except Exception:
            return {}

    # Utilities --------------------------------------------------------------
    def clear_all_state(self) -> None:
        """Delete all known state files (reset the starter's local state)."""
        for name in ["order_states.json", "delivery_states.json", "consumer_offsets.json"]:
            p = self._path(name)
            if os.path.exists(p):
                try:
                    os.remove(p)
                except Exception:
                    pass

    @staticmethod
    def _now() -> str:
        return datetime.utcnow().isoformat() + "Z"
