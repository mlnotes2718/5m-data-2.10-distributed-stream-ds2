"""Operations Manager (template)

Provide action controls for operators. For example:
- update a status
- trigger a workflow
- clear processed items
"""

import streamlit as st
try:
    from starter.kafka.producer import get_department_producer, DEFAULT_TOPICS
except Exception:
    from kafka.producer import get_department_producer, DEFAULT_TOPICS
try:
    from starter.services.app_state import save_application_states
except Exception:
    from services.app_state import save_application_states


def publisher_topic_management():
    """Send updates/commands to topics; add operator actions here.

    Teaches:
    - how to publish a message to a topic from a control panel
    - how to mirror a result into local state to keep the UI responsive
    """
    st.title("🛠️ Publisher Topic Management (Template)")
    st.caption("Send updates/commands to topics; add operator actions here.")

    try:
        producer = get_department_producer()
    except Exception as e:
        st.error(f"Producer init failed: {e}")
        return

    order_id = st.text_input("Order/Event ID", value="demo123")
    new_status = st.selectbox("New Status", ["created", "processing", "done"]) 
    if st.button("Publish Message"):
        payload = {"id": order_id, "event": "status_update", "timestamp": "", "payload": {"status": new_status}}
        ok, msg = producer.produce_json(payload, topic=DEFAULT_TOPICS["status"], key=order_id)
        if ok:
            st.success("Status update sent")
            # mirror in local state for demo UX
            st.session_state.setdefault("order_statuses", {})[order_id] = new_status
            save_application_states()
        else:
            st.error(f"Send failed: {msg}")


if __name__ == "__main__":
    publisher_topic_management()
else:
    publisher_topic_management()
