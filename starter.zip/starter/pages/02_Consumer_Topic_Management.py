"""Tracking Dashboard (template)

Use this page to show recent events and status timelines for your domain.
Consumes a topic and renders recent messages.
"""

import streamlit as st
try:
    from starter.kafka.consumer import get_department_consumer, DEFAULT_TOPICS
except Exception:
    from kafka.consumer import get_department_consumer, DEFAULT_TOPICS


def consumer_topic_management():
    """Manage consumption of a topic and display recent messages.

    Teaches:
    - starting/stopping a background consumer thread
    - reading a rolling buffer of parsed JSON messages
    - how to extend with filters, joins, or metrics
    """
    st.title("📡 Consumer Topic Management (Template)")
    st.caption("Start/stop a consumer, view recent messages, and manage consumption.")

    consumer = get_department_consumer("dept-tracking-consumer")
    if st.button("Start Consumer"):
        consumer.start_consuming([DEFAULT_TOPICS["orders"]])
        st.rerun()
    if st.button("Stop Consumer"):
        consumer.stop_consuming()
        st.rerun()

    messages = consumer.get_recent_messages(50)
    if not messages:
        st.info("No messages yet. Start the consumer and send some events from Orders Dashboard.")
        return

    for msg in reversed(messages[-10:]):
        with st.expander(f"Event {msg.get('event','?')} — ID {msg.get('id','?')}"):
            st.json(msg)


if __name__ == "__main__":
    consumer_topic_management()
else:
    consumer_topic_management()
