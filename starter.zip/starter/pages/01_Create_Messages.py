"""Create Messages (template)

Adapt this page for your department's primary ingestion workflow (e.g.,
order intake, inventory events, feedback submissions). The template shows
how to gather inputs and send a JSON message to Kafka.
"""

import uuid
import streamlit as st
try:
    from starter.services.app_state import save_application_states
except Exception:
    from services.app_state import save_application_states
try:
    from starter.kafka.producer import get_department_producer, DEFAULT_TOPICS
except Exception:
    from kafka.producer import get_department_producer, DEFAULT_TOPICS


def create_messages():
    """Render a simple form to publish JSON messages to Kafka.

    Teaches:
    - how to collect inputs in Streamlit
    - how to send a JSON payload with a key via DepartmentProducer
    - where to save state locally for cross-session demos
    """
    st.title("📥 Create Messages (Template)")
    st.caption("Customize this to your domain. Publishes JSON messages to a topic.")

    try:
        producer = get_department_producer()
    except Exception as e:
        st.error(f"Producer init failed: {e}")
        return

    # Use a form so Streamlit groups inputs with one submit action
    with st.form("dept_create_form"):
        # Example fields; replace with your department data
        customer = st.text_input("Customer", value="Demo Customer")
        item = st.text_input("Item", value="Margherita Pizza")
        notes = st.text_area("Notes", value="No olives")
        submitted = st.form_submit_button("Send Event")

    if submitted:
        # Build a minimal event. Departments should replace with their schema.
        event = {
            "id": uuid.uuid4().hex[:8],
            "event": "order_created",
            "timestamp": st.session_state.get("_now", ""),
            "payload": {"customer": customer, "item": item, "notes": notes},
        }
        ok, msg = producer.produce_json(event, topic=DEFAULT_TOPICS["orders"], key=event["id"])
        if ok:
            st.success("Event sent")
            st.json(event)
            # Optionally also keep a local list for cross-session demos
            st.session_state.setdefault("messages", []).append(event)
            save_application_states()
        else:
            st.error(f"Send failed: {msg}")


if __name__ == "__main__":
    create_messages()
else:
    create_messages()
