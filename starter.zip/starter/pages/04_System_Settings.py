"""System Settings (template)

Create/delete/flush topics and clear app state.
"""

import streamlit as st
try:
    from starter.services.kafka_admin import get_admin_client, list_topics, create_topic, delete_topic, flush_topics
except Exception:
    from services.kafka_admin import get_admin_client, list_topics, create_topic, delete_topic, flush_topics
try:
    from starter.services.app_state import clear_application_state
except Exception:
    from services.app_state import clear_application_state


def system_settings():
    st.title("⚙️ System Settings (Template)")
    admin = get_admin_client()
    if not admin:
        st.error("Kafka not connected. Check .env")
        return

    topics = list(list_topics(admin).keys())
    st.write("Existing topics:", topics)

    st.subheader("Create Topic")
    tname = st.text_input("Topic name")
    parts = st.number_input("Partitions", min_value=1, max_value=100, value=1, step=1)
    if st.button("Create") and tname:
        ok = create_topic(admin, tname, partitions=parts)
        st.success("Created") if ok else st.error("Create failed")

    st.subheader("Delete Topic")
    todel = st.selectbox("Select topic", topics)
    if st.button("Delete"):
        ok = delete_topic(admin, todel)
        st.warning("Deleted") if ok else st.error("Delete failed")

    st.subheader("Flush Topics (Delete + Recreate)")
    toflush = st.multiselect("Select topics", topics)
    parts2 = st.number_input("Recreate partitions", min_value=1, max_value=100, value=1, step=1)
    also_clear = st.checkbox("Also clear app state", value=True)
    if st.button("Flush Selected") and toflush:
        res = flush_topics(admin, toflush, partitions=parts2)
        st.success(res)
        if also_clear:
            clear_application_state()
            st.info("App state cleared.")


if __name__ == "__main__":
    system_settings()
else:
    system_settings()
