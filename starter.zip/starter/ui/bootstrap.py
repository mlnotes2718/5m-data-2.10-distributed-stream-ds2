"""Bootstrap utilities shared by pages.

Responsibilities:
- Initialize StateManager into Streamlit session
- Optionally init AdminClient and DuckDB engine
- Provide a simple sidebar status with Kafka connectivity and order counts
"""

import streamlit as st
from dotenv import load_dotenv
# Support both root-level and nested `starter/` imports for relocatability.
try:
    from starter.state_manager import StateManager
    from starter.services.kafka_admin import get_admin_client, list_topics
    from starter.services.app_state import periodic_save
except Exception:
    from state_manager import StateManager
    from services.kafka_admin import get_admin_client, list_topics
    from services.app_state import periodic_save

try:
    from starter.services.duckdb_engine import DuckDBEngine
except Exception:
    try:
        from services.duckdb_engine import DuckDBEngine
    except Exception:
        DuckDBEngine = None


def initialize():
    """Initialize shared objects in Streamlit session_state.

    Called once per session to prepare:
    - state_manager: JSON persistence helper
    - admin_client: Kafka AdminClient (may be None if .env missing)
    - duckdb_engine: Optional in-process SQL over JSON files
    """
    if "state_manager" not in st.session_state:
        st.session_state.state_manager = StateManager()
    if "admin_client" not in st.session_state:
        st.session_state.admin_client = get_admin_client()
    if DuckDBEngine and "duckdb_engine" not in st.session_state:
        try:
            st.session_state.duckdb_engine = DuckDBEngine()
        except Exception:
            st.session_state.duckdb_engine = None

    # Load .env from current working directory for relocatable starter.
    try:
        load_dotenv()
    except Exception:
        pass


def sidebar_status():
    """Render a simple sidebar status and run periodic saves.

    Intended as a place to wire health checks and background work.
    """
    st.sidebar.markdown("---")
    st.sidebar.subheader("System Status")
    admin_client = st.session_state.get("admin_client")
    if admin_client:
        st.sidebar.success("Kafka: Connected")
        try:
            topics = list_topics(admin_client)
            st.sidebar.caption(f"Topics: {len(topics)}")
        except Exception:
            pass
    else:
        st.sidebar.error("Kafka: Disconnected")

    orders, statuses = st.session_state.state_manager.load_order_states()
    processed = sum(1 for s in statuses.values() if s == "delivered")
    st.sidebar.caption(f"Orders: {len(orders)} (delivered {processed})")

    periodic_save(30)
