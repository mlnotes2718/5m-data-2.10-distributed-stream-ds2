"""
Kafka admin helpers for starter apps.

These wrap confluent_kafka AdminClient calls for:
- listing topics
- creating/deleting topics
- flushing topics (delete + recreate)

Notes for beginners:
- This uses your Confluent Cloud credentials from environment variables (.env).
- You typically should not call these from inside a hot code-path; they are admin actions.
"""

import os
from typing import Dict, Any, List, Optional

from confluent_kafka.admin import AdminClient, NewTopic
from confluent_kafka import KafkaException


def get_admin_client() -> Optional[AdminClient]:
    """Create an AdminClient from env vars or return None on error.

    Reads BOOTSTRAP_SERVERS, API_KEY, API_SECRET from environment.
    Departments can reuse this client for topic operations.
    """
    bootstrap_servers = os.getenv("BOOTSTRAP_SERVERS")
    api_key = os.getenv("API_KEY")
    api_secret = os.getenv("API_SECRET")
    if not all([bootstrap_servers, api_key, api_secret]):
        return None
    try:
        return AdminClient(
            {
                "bootstrap.servers": bootstrap_servers,
                "sasl.mechanisms": "PLAIN",
                "security.protocol": "SASL_SSL",
                "sasl.username": api_key,
                "sasl.password": api_secret,
            }
        )
    except KafkaException:
        return None


def list_topics(admin_client: AdminClient) -> Dict[str, Any]:
    """Return the broker's topic metadata map.

    Use this to inspect topic names and partition layouts.
    """
    md = admin_client.list_topics(timeout=10)
    return md.topics


def create_topic(admin_client: AdminClient, topic: str, partitions: int = 1, replication_factor: int = 3) -> bool:
    """Create a topic. Defaults to 1 partition (demo-friendly).

    Return True if broker reports success, else False.
    """
    new_topic = NewTopic(topic, num_partitions=partitions, replication_factor=replication_factor)
    fs = admin_client.create_topics([new_topic])
    for _, f in fs.items():
        try:
            f.result()
        except KafkaException:
            return False
    return True


def delete_topic(admin_client: AdminClient, topic: str) -> bool:
    """Delete a topic. Returns True on success."""
    fs = admin_client.delete_topics([topic])
    for _, f in fs.items():
        try:
            f.result()
        except KafkaException:
            return False
    return True


def flush_topics(admin_client: AdminClient, topics: List[str], partitions: int = 1, replication_factor: int = 3) -> Dict[str, Dict[str, bool]]:
    """Delete and recreate topics to purge all data. Returns per-topic results.

    This is the simplest way to "flush" in demos; production systems
    typically adjust retention or use admin APIs to alter log segments.
    """
    results: Dict[str, Dict[str, bool]] = {}
    for t in topics:
        deleted = delete_topic(admin_client, t)
        created = create_topic(admin_client, t, partitions=partitions, replication_factor=replication_factor)
        results[t] = {"deleted": deleted, "created": created}
    return results
