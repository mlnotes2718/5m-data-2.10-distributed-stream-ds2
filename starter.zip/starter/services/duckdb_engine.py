"""DuckDB helper to query JSON state files directly.

This is optional but very handy for ad-hoc joins and metrics without
introducing a DB server. Departments can keep using JSON while
querying with SQL.
"""

from __future__ import annotations

from typing import Dict


class DuckDBEngine:
    def __init__(self, state_dir: str = "starter_state"):
        self.state_dir = state_dir
        self._con = None

    def _conn(self):
        """Create or return a DuckDB connection (in-process DB).

        We try to load the JSON extension to enable convenient file scanning.
        """
        if self._con is None:
            import duckdb

            self._con = duckdb.connect()
            # JSON extension is bundled in recent DuckDB
            try:
                self._con.execute("INSTALL json;")
                self._con.execute("LOAD json;")
            except Exception:
                pass
        return self._con

    def get_counts(self) -> Dict[str, int]:
        """Return quick totals from JSON state on disk.

        Shows how to treat JSON files as tables and run SQL with DuckDB.
        """
        con = self._conn()
        orders_path = f"{self.state_dir}/order_states.json"
        q = f"""
        WITH os AS (SELECT * FROM read_json_auto('{orders_path}')),
        o AS (SELECT UNNEST(orders) AS ord FROM os),
        s AS (SELECT key AS order_id, value AS status FROM os, json_each(order_statuses))
        SELECT count(*) AS total,
               sum(CASE WHEN status='delivered' THEN 1 ELSE 0 END) AS processed
        FROM o LEFT JOIN s ON s.order_id = ord->>'order_id'
        """
        df = con.sql(q).df()
        if df.empty:
            return {"total": 0, "processed": 0, "in_progress": 0}
        total = int(df.loc[0, "total"])
        processed = int(df.loc[0, "processed"])
        return {"total": total, "processed": processed, "in_progress": total - processed}

    def join_state_by_key(self, key_field: str = "id"):
        """
        Generic example: Given a JSON state file that contains an array of
        records (orders/messages) and a map of statuses keyed by a field,
        join them on the selected key field.

        For the starter, we reuse order_states.json with structure:
          { "orders": [ {...} ], "order_statuses": { <id>: <status>, ... } }

        key_field: the name inside each order/message to join with the
                   keys of order_statuses.
        Returns a DataFrame: columns include key_field, status, and all fields.
        Departments may adapt this function to point at their own files.
        """
        con = self._conn()
        path = f"{self.state_dir}/order_states.json"
        q = f"""
        WITH os AS (SELECT * FROM read_json_auto('{path}')),
        o AS (SELECT UNNEST(orders) AS ord FROM os),
        s AS (SELECT key AS status_key, value AS status FROM os, json_each(order_statuses))
        SELECT ord->>'{key_field}' AS {key_field}, ord AS record, s.status
        FROM o LEFT JOIN s ON s.status_key = ord->>'{key_field}'
        """
        return con.sql(q).df()
