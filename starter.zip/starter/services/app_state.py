"""Minimal app-state helpers for starter apps.

This module shows how to:
- periodically save Streamlit session state to JSON via StateManager
- clear app state (files + in-memory) for a clean slate

Departments can copy/extend this to match their own session data.
"""

import time
import streamlit as st
try:
    from starter.state_manager import StateManager
except Exception:
    from state_manager import StateManager


def save_application_states() -> None:
    """Save common state keys if present.

    This function demonstrates a simple persistence pattern:
    - Gather relevant session keys
    - Persist them via a single manager
    Call it periodically or after important actions.
    """
    if "state_manager" not in st.session_state:
        st.session_state.state_manager = StateManager()
    sm: StateManager = st.session_state.state_manager

    orders = st.session_state.get("orders", [])
    statuses = st.session_state.get("order_statuses", {})
    sm.save_order_states(orders, statuses)

    in_progress = st.session_state.get("in_progress_orders", [])
    processed = st.session_state.get("processed_orders", [])
    sm.save_delivery_states(in_progress, processed)

    # Example: Persist consumer offsets if you track them
    offsets = st.session_state.get("consumer_offsets", {})
    if offsets:
        sm.save_consumer_offsets(offsets)


def periodic_save(interval_seconds: int = 30) -> None:
    """Save states every N seconds; call from sidebar or a page root.

    Streamlit reruns your script often (on widget changes). Using a lightweight
    clock in session_state helps throttle disk writes.
    """
    if "last_save_time" not in st.session_state:
        st.session_state.last_save_time = 0
    now = time.time()
    if now - st.session_state.last_save_time > interval_seconds:
        save_application_states()
        st.session_state.last_save_time = now


def clear_application_state() -> None:
    """Delete persisted files and clear in-memory session keys.

    Use this before demos or tests to ensure a clean slate.
    """
    if "state_manager" not in st.session_state:
        st.session_state.state_manager = StateManager()
    sm: StateManager = st.session_state.state_manager
    sm.clear_all_state()

    for key in [
        "orders",
        "order_statuses",
        "in_progress_orders",
        "processed_orders",
        "consumer_offsets",
        "last_save_time",
        "states_loaded",
    ]:
        if key in st.session_state:
            del st.session_state[key]
