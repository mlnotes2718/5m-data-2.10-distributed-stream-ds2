Agent Guide: Extending the Department Starter App

This guide helps an AI assistant safely expand the starter into a working kafka based dashboard.

Working Principles
- Keep changes minimal and well-commented.
- Prefer configuration over hard-coding. Never commit secrets.
- Follow Streamlit Pages ordering and naming.

Key Files (assume this folder is the repository root)
- app.py: Welcome dashboard and metrics
- pages/: Pages (Create Messages, Consumer Topic Management, Publisher Topic Management, System Settings)
- kafka/: Producer and Consumer wrappers
- services/: Admin client, app state, DuckDB engine
- state_manager.py: JSON-backed persistence

Common Tasks
- Add page: copy an existing page under pages/, rename with an order prefix (e.g., 05_My_Team_View.py)
- Change topics: edit DEFAULT_TOPICS in kafka/{producer,consumer}.py
- Validate schemas: edit schemas/schemas.py and call validator
- Query JSON with SQL: use services/duckdb_engine.DuckDBEngine.get_counts() or join_state_by_key(key_field)
- Reset state/topics: use the System Settings page (Flush + Clear state)

Guardrails
- Treat this directory as the project root; avoid creating parallel roots
- When adding deps, update requirements.txt (or environment.yml if using conda)
- Keep changes small and explain breaking changes in README and code comments
