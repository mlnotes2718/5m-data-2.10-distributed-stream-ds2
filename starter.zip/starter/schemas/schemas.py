"""Schemas and validation helpers (JSONSchema).

Departments should copy the pattern:
- define schema(s)
- validate messages before producing/after consuming
"""

import jsonschema
from typing import Dict, Any, Tuple


# Example schema (edit to match your domain):
EVENT_SCHEMA_V1 = {
    "$schema": "http://json-schema.org/draft-07/schema#",
    "type": "object",
    "title": "Department Event v1",
    "properties": {
        "id": {"type": "string"},
        "event": {"type": "string"},
        "timestamp": {"type": "string"},
        "payload": {"type": "object"},
    },
    "required": ["id", "event", "timestamp"],
    "additionalProperties": True,
}


class SchemaValidator:
    """Small helper around jsonschema for starter events.

    Departments can create multiple validators if they manage more than
    one event type/version. Keep validators close to schemas for clarity.
    """
    def __init__(self):
        self._validator = jsonschema.Draft7Validator(EVENT_SCHEMA_V1)

    def validate(self, data: Dict[str, Any]) -> Tuple[bool, list[str]]:
        """Validate a dict against EVENT_SCHEMA_V1.

        Returns (is_valid, errors). In Streamlit, surface errors to the user.
        """
        errors = [e.message for e in self._validator.iter_errors(data)]
        return (len(errors) == 0, errors)
